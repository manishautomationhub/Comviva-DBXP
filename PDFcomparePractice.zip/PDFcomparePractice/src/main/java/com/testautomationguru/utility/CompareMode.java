package com.testautomationguru.utility;

	 public enum CompareMode {
	 	TEXT_MODE,
	 	VISUAL_MODE
	 }
	
